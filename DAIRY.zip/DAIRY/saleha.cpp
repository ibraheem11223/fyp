#include <iostream>
#include<conio.h>
#include <fstream>
using namespace std;

void add_entry(string date, string entry) {
    ofstream diary_file("diary.txt", ios::app);
    diary_file << date << ": " << entry << endl;
    diary_file.close();
    cout << "Entry added successfully!" << endl;
    cout<<"Press enter to continue";
    getche();
    system("cls");
}

void view_entries() {
    ifstream diary_file("diary.txt");
    string line;
    cout << "Diary Entries:" << endl;
    while (getline(diary_file, line)) {
        cout << line << endl;
    }
    diary_file.close();
    cout<<"Press enter to continue";
    getche();
    system("cls");
}
void Display()
{
	cout<<" _______________________________________________________________________________________________________________________";
	cout<<"                                                   Personal Diary                                                      ";
	cout<<" ________________________________________________________________________________________________________________________";
}

int main() {
    while (true) {
    	Display();
        cout << "1. Add entry" << endl;
        cout << "2. View entries" << endl;
        cout << "3. Exit" << endl;
        int choice;
        cin >> choice;

        if (choice == 1) {
            string date, entry;
            cout << "Enter date (YYYY-MM-DD): ";
            cin >> date;
            cout << "Enter entry: ";
            cin>> entry;
            add_entry(date, entry);
        }
        else if (choice == 2) {
            view_entries();
        }
        else if (choice == 3) {
        	cout<<"Thankyou for using my program"<<endl;
        	cout<<"Press any key to exit";
        	getch();
        	 exit(0);
        	break;
        }
       
    }
}