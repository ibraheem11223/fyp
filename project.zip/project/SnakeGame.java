import java.util.*;
import javax.imageio.ImageIO; //It contain static convineance  method for locting image reader and image writer
// and performing simple encoding and decoding functions
import java.util.Timer;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.swing.*;
/*Enum, introduced in Java 5, is a special data type that
 consists of a set of pre-defined named values separated by commas.
 These named values are also known as elements or enumerators or enum instances.
  Since the values in the enum type are constant, 
  you should always represent them in UPPERCASE letters. */
enum GameStatus {
    NOT_STARTED, RUNNING, PAUSED, GAME_OVER
}
/*Direction Enum Constants (UP, DOWN, LEFT, RIGHT): 
These represent different directions (up, down, left, right).

isX() Method:

This method is defined within the Direction enum.
It returns true if the current direction is either LEFT or RIGHT.
It is used to check if the direction is along the x-axis.
isY() Method:

Similar to isX(), this method returns true if the current direction is either UP or DOWN.
It is used to check if the direction is along the y-axis. */
enum Direction {
    UP, DOWN, LEFT, RIGHT;

    public boolean isX() {
        return this == LEFT || this == RIGHT;
    }

    public boolean isY() {
        return this == UP || this == DOWN;
    }
}
/*Point Class:

Represents a point in a 2D space with coordinates (x, y).

Constructor:
The first constructor initializes a Point object with the given x and y coordinates.

Copy Constructor:
The second constructor takes another Point object p and 
creates a new Point with the same coordinates as p. 
It essentially creates a copy of the Point object. */

class Point {
    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public Point(Point p) {
        this.x = p.getX();
        this.y = p.getY();
    }

    /*public void move(Direction d, int value):
Purpose: Moves the point in a specified direction by a given value.
Parameters:
d: The direction (UP, DOWN, LEFT, RIGHT).
value: The distance to move in the specified direction.
public int getX():
Purpose: Returns the x-coordinate of the point.
Return Type: int
public int getY():
Purpose: Returns the y-coordinate of the point.
Return Type: int
public Point setX(int x):
Purpose: Sets the x-coordinate of the point and returns the modified Point object.
Parameters:
x: The new x-coordinate.
public Point setY(int y):
Purpose: Sets the y-coordinate of the point and returns the modified Point object.
Parameters:
y: The new y-coordinate.
*/
    public void move(Direction d, int value) {
        switch (d) {
            case UP:
                this.y -= value;
                break;
            case DOWN:
                this.y += value;
                break;
            case RIGHT:
                this.x += value;
                break;
            case LEFT:
                this.x -= value;
                break;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Point setX(int x) {
        this.x = x;
        return this;
    }

    public Point setY(int y) {
        this.y = y;
        return this;
    }

    /*public boolean equals(Point p):
    Purpose: Checks if the current Point is equal to another Point.
    Parameters:
    p: The other Point to compare.
    Return Type: boolean
    public String toString():
    Purpose: Returns a string representation of the point in the format "(x, y)".
    Return Type: String
    
    In summary, this Point class provides methods for moving, getting and setting coordinates, 
    checking equality, generating a string representation, and checking for intersection between points. 
    It is designed for 2D point manipulation in applications such as graphics or game development.  */
    public boolean equals(Point p) {
        return this.x == p.getX() && this.y == p.getY();
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }
/*public boolean intersects(Point p):
    Purpose: Checks if the current Point intersects with another 
    Point within a default tolerance of 10 units.
    Parameters:
    p: The other Point to check for intersection.
    Return Type: boolean
    public boolean intersects(Point p, int tolerance):
    Purpose: Checks if the current Point intersects with another Point within a specified tolerance.
    Parameters:
    p: The other Point to check for intersection.
    tolerance: The allowed tolerance for intersection.
    Return Type: boolean */
    public boolean intersects(Point p) {
        return p != null && intersects(p, 10);
    }   
    /*Parameters:

    Point p: The other point to check for intersection or proximity.
    int tolerance: A measure of how close the two points can be to each other and still be considered intersecting.
    Functionality:

    int diffX = Math.abs(x - p.getX()) and int diffY = Math.abs(y - p.getY()): 
    Calculate the absolute differences between the x-coordinates and y-coordinates of the current point (this) and the other point (p).

    this.equals(p): Checks if the two points are exactly equal. If they are, there is an intersection, and the method returns true.

    (diffX <= tolerance && diffY <= tolerance): 
    Checks if the absolute differences in both x and y coordinates are within the specified tolerance. 
    If they are, the points are considered close enough, and the method returns true. */

    public boolean intersects(Point p, int tolerance) {
        int diffX = Math.abs(x - p.getX());
        int diffY = Math.abs(y - p.getY());
        return this.equals(p) || (diffX <= tolerance && diffY <= tolerance);
    }
}

class Snake {
    private Direction direction;
    private Point head;
    private LinkedList<Point> tail;

    public Snake(int x, int y) {
        this.head = new Point(x, y);
        this.direction = Direction.RIGHT;
        this.tail = new LinkedList<Point>();
        this.tail.add(new Point(0, 0));
        this.tail.add(new Point(0, 0));
        this.tail.add(new Point(0, 0));
    }

    /*Snake Class:
Attributes:

direction: Represents the current direction of the snake (UP, DOWN, LEFT, RIGHT).
head: Represents the head of the snake, which is an instance of the Point class.
tail: Represents the body of the snake, stored as a linked list of Point objects.
Constructor:

Initializes the snake with a specified starting position (x and y coordinates), initial direction (RIGHT), and a default tail consisting of three points.
move() Method:

Changes the direction of the snake if the new direction is orthogonal to the current direction (prevents the snake from turning back on itself).
Getter Methods:

getTail(): Returns the linked list representing the snake's tail.
getHead(): Returns the Point representing the snake's head.
SnakeGame Class:
Attributes:
 */

    public void move() {
        LinkedList<Point> newTail = new LinkedList<Point>();
        for (int i = 0, size = tail.size(); i < size; i++) {
            Point previous = i == 0 ? head : tail.get(i - 1);
            newTail.add(new Point(previous.getX(), previous.getY()));
        }
        this.tail = newTail;
        this.head.move(this.direction, 10); //value  == speed]
    }

    /*Updates the snake's position by moving its head in the current direction.
The tail is updated by shifting each element to the position of the previous one, effectively following the head.
The head is moved by calling the move method of the Point class, adjusting the coordinates based on the current direction.
addTail() Method:

Adds a new point (Point(-10, -10)) to the tail of the snake.
turn(Direction d) Method: */


    public void addTail() {
        this.tail.add(new Point(-10, -10));
    }

    public void turn(Direction d) {
        if (d.isX() && direction.isY() || d.isY() && direction.isX()) {
            direction = d;
        }
    } //checks if  the snake is moving left to right if yes then allow it to move up and down or vise versa

    public LinkedList<Point> getTail() {
        return this.tail;
    }

    public Point getHead() {
        return this.head;
    }
}

public class SnakeGame extends JFrame {
    private GamePanel gamePanel;

    public SnakeGame() {
        initUI();
    }

    /*gamePanel: An instance of the GamePanel class, which is a panel used for rendering the game.
    Constructor:

    Initializes the SnakeGame by calling the initUI() method.
    initUI() Method:

    Sets up the graphical user interface (GUI) for the game.
    Creates a GamePanel and adds it to the SnakeGame frame.
    Sets the title, size, location, and close operation for the frame.
    GamePanel Class: 
    */
    private void initUI() {
        gamePanel = new GamePanel();
        add(gamePanel);

        setTitle("Snake Game");
        setSize(800, 610);

        setLocationRelativeTo(null); //this line ensures that when the game window is displayed, 
                                       //it will be positioned at the center of the screen.
        setResizable(false); //means that the user cannot resize the frame manually by dragging its edges or corners.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //It ensures that the program terminates when the user closes the game window.
    }

    /*Starting Point:

This is where the program begins to run.
EventQueue.invokeLater(...):

Think of it as a way to ensure that certain things related to the graphical part of the program happen in the right order.
Inside the Runnable (Lambda Expression):

Creates a new game window for a Snake game. Imagine this as setting up the game board.
Makes the game board visible, so you can see and interact with it.
What It Does in Simple Terms:

When you run the program, it opens a window for playing the Snake game.
The SnakeGame class takes care of creating and managing this window.
setVisible(true) is like turning on the lights in the room; it makes the game visible on your screen. */
    public static void main(String[] args) {
        //The EventQueue.invokeLater method is used to ensure that the specified code is executed on the Event Dispatch Thread (EDT).
        EventQueue.invokeLater(() -> { //The () -> syntax is a lambda expression, a concise way of representing an anonymous function or method.
            SnakeGame snakeGame = new SnakeGame();
            snakeGame.setVisible(true);
        });
    }
}

class GamePanel extends JPanel {
    private Timer timer;
    private Snake snake;
    private Point cherry;
    private int points = 0;
    private int best = 0;
    private BufferedImage cherryImage;
    private GameStatus status;
    private boolean didLoadCherryImage = true;

    private static Font FONT_M = new Font("MV Boli", Font.PLAIN, 24);
    private static Font FONT_M_ITALIC = new Font("MV Boli", Font.ITALIC, 24);
    private static Font FONT_L = new Font("MV Boli", Font.PLAIN, 84);
    private static Font FONT_XL = new Font("MV Boli", Font.PLAIN, 150);
    private static int WIDTH = 760;
    private static int HEIGHT = 520;
    private static int DELAY = 50;

    /*Class GamePanel:
Attributes:

timer: A Timer object used for scheduling regular updates of the game.
snake: An instance of the Snake class representing the player-controlled snake.
cherry: A point representing the cherry that the snake can eat.
points: An integer representing the player's score.
best: An integer representing the player's best (highest) score.
cherryImage: A BufferedImage representing the image of the cherry.

status: An enumeration (GameStatus) 
representing the current state of the game (NOT_STARTED, RUNNING, PAUSED, GAME_OVER).

didLoadCherryImage: A boolean indicating whether the cherry image was successfully loaded.
Various fonts, dimensions, and delay parameters.
Constructor (public GamePanel()):

Initializes the GamePanel:
Attempts to load the cherry image from a file. If unsuccessful, sets didLoadCherryImage to false.
Adds a key listener (GameKeyListener) to handle user input.
Sets the background color, focuses the panel, and enables double buffering.
Initializes the Snake object with a starting position and sets the initial game status to NOT_STARTED.



Extends java.util.TimerTask to define the periodic update task for the game.
In summary, this code defines the main game panel with functionality for updating and rendering the Snake game. 
It includes features such as scoring, cherry spawning, and basic game state management. */
    public GamePanel() {
        try {
            cherryImage = ImageIO.read(new File("cherry.png"));
        } catch (IOException e) {
            didLoadCherryImage = false;
        }

        addKeyListener(new GameKeyListener());  //Attaches a GameKeyListener instance to the GamePanel. 
                                                //This listener will handle keyboard input for the game.
        setFocusable(true); //Sets the GamePanel to be focusable. 
        //This is necessary for the panel to receive keyboard input events. Without this, the panel won't respond to key presses.
        setBackground(new Color(130, 205, 71));
        setDoubleBuffered(true);

        snake = new Snake(WIDTH / 2, HEIGHT / 2);
        status = GameStatus.NOT_STARTED;
        repaint(); // This is done to ensure that the initial state of the game is displayed.
    }

    /*
    paintComponent(Graphics g) Method:
Overrides the paintComponent method to render the game graphics.
 */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        render(g);
        /*Toolkit is a class in the java.awt package that provides a common set of tools and resources for GUI components.
        getDefaultToolkit() is a static method that returns the default toolkit for the desktop environment. */
        Toolkit.getDefaultToolkit().sync();
        /*Synchronization is crucial in graphics programming to ensure that changes made to the graphics state 
        (like drawing operations) are consistently and accurately reflected on the screen.
        Different platforms or operating systems may have variations in how they handle graphics, 
        and the sync() method helps in making sure that the graphics state is consistent across these platforms. */
    }

    /*
    update() Method:
    Updates the game state in response to user input and other events:
Moves the snake.
Checks if the snake has eaten the cherry and updates the score.
Spawns a new cherry if none exists.
Checks for game over conditions.
reset() Method:
 */

    private void update() {
        snake.move();

        if (cherry != null && snake.getHead().intersects(cherry, 7)) {
            snake.addTail();
            cherry = null;
            points++;
        }

        if (cherry == null) {
            spawnCherry();
        }

        checkForGameOver();
    }

    /*Resets the game state when restarting the game.
Resets the score, cherry, and creates a new snake.
Sets the game status to RUNNING.
setStatus(GameStatus newStatus) Method: */

    private void reset() {
        points = 0;
        cherry = null;
        snake = new Snake(WIDTH / 2, HEIGHT / 2);
        setStatus(GameStatus.RUNNING);
    }

    private void setStatus(GameStatus newStatus) {
        switch (newStatus) {
            case RUNNING:
                timer = new Timer();
                timer.schedule(new GameLoop(), 0, DELAY);
                break;
            case PAUSED:
            case GAME_OVER:
                timer.cancel();
                best = points > best ? points : best;
                break;
        }
        status = newStatus;
    }
    /*Sets the game status and performs corresponding actions:
If the status is RUNNING, starts a timer to schedule game updates.
If the status is PAUSED or GAME_OVER, cancels the timer and updates the best score.
togglePause() Method: */
    private void togglePause() {
        setStatus(status == GameStatus.PAUSED ? GameStatus.RUNNING : GameStatus.PAUSED);
    }

    /*Toggles the game between paused and running states.
checkForGameOver() Method:
*/
    private void checkForGameOver() {
        Point head = snake.getHead();
        boolean hitBoundary = head.getX() <= 20 || head.getX() >= WIDTH + 10
                || head.getY() <= 40 || head.getY() >= HEIGHT + 30; // checks head = left/ right or up/down

        boolean ateItself = false;

        for (Point t : snake.getTail()) {
            ateItself = ateItself || head.equals(t); // checks for head at every tail point
        }

        if (hitBoundary || ateItself) {
            setStatus(GameStatus.GAME_OVER);
        }
    }

    /*Checks if the game is over based on boundary collisions or if the snake has eaten itself.
render(Graphics g) Method:  */

/*Renders various game elements using the provided Graphics2D object.
drawCenteredString(Graphics g, String text, Font font, int y) Method:

Draws a centered string at a specified y-coordinate.
spawnCherry() Method:

Spawns a new cherry at a random position within the game boundaries.
GameKeyListener Inner Class:

Handles keyboard input for controlling the snake and managing game state transitions.
GameLoop Inner Class: */
    private void render(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(Color.BLACK);
        g2d.setFont(FONT_M);

        if (status == GameStatus.NOT_STARTED) {
            drawCenteredString(g2d, "SNAKE", FONT_XL, 200);
            drawCenteredString(g2d, "GAME", FONT_XL, 300);
            drawCenteredString(g2d, "Press  any  key  to  begin", FONT_M_ITALIC, 330);
            return;
        }

        Point p = snake.getHead();

        g2d.drawString("SCORE: " + String.format("%02d", points), 20, 30);
        g2d.drawString("BEST: " + String.format("%02d", best), 630, 30);

        if (cherry != null) {
            if (didLoadCherryImage) {
                g2d.drawImage(cherryImage, cherry.getX(), cherry.getY(), 60, 60, null);
            } else {
                g2d.setColor(Color.BLACK);
                g2d.fillOval(cherry.getX(), cherry.getY(), 10, 10);
            }
        }

        if (status == GameStatus.GAME_OVER) {
            drawCenteredString(g2d, "Press  enter  to  start  again", FONT_M_ITALIC, 330);
            drawCenteredString(g2d, "GAME OVER", FONT_L, 300);
        }

        if (status == GameStatus.PAUSED) {
            g2d.drawString("Paused", 600, 14);
            
        }

        g2d.setColor(new Color(33, 70, 199)); // Snake color
        g2d.fillRect(p.getX(), p.getY(), 10, 10); 

        for (int i = 0, size = snake.getTail().size(); i < size; i++) {
            Point t = snake.getTail().get(i);
            g2d.fillRect(t.getX(), t.getY(), 10, 10);
        }

        //Setting bordors color amd size
        g2d.setColor(Color.RED);
        g2d.setStroke(new BasicStroke(4));
        g2d.drawRect(20, 40, WIDTH, HEIGHT);
    }

    public void drawCenteredString(Graphics g, String text, Font font, int y) {
        FontMetrics metrics = g.getFontMetrics(font); //FOR RENDERRING A SPECIFIC FONT
        int x = (WIDTH - metrics.stringWidth(text)) / 2;
        g.setFont(font);
        g.drawString(text, x, y);
    }

    public void spawnCherry() {
        cherry = new Point((new Random()).nextInt(WIDTH - 60) + 20,  // x axis width -60 set the upper limit of boundary and 
        //+20 prevent it to generate v close to the boundary
                (new Random()).nextInt(HEIGHT - 60) + 40);
    }
    //This is a private inner class that extends KeyAdapter,
    //which is a convenient class for receiving keyboard events.
    private class GameKeyListener extends KeyAdapter { 
        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode(); //when input from keyboard is pressed it takes it in get...

            if (status == GameStatus.RUNNING) {
                switch (key) {
                    case KeyEvent.VK_LEFT:
                        snake.turn(Direction.LEFT);
                        break;
                    case KeyEvent.VK_RIGHT:
                        snake.turn(Direction.RIGHT);
                        break;
                    case KeyEvent.VK_UP:
                        snake.turn(Direction.UP);
                        break;
                    case KeyEvent.VK_DOWN:
                        snake.turn(Direction.DOWN);
                        break;
                }
            }

            if (status == GameStatus.NOT_STARTED) {
                setStatus(GameStatus.RUNNING);
            }

            if (status == GameStatus.GAME_OVER && key == KeyEvent.VK_ENTER) {
                reset();
            }

            if (key == KeyEvent.VK_P) {
                togglePause();
            }
        }
    }

    private class GameLoop extends java.util.TimerTask {
        @Override
        public void run() {
            update();
            repaint();
        }
    }
}
