function createSyntheticSoundButtons()
    % Create a figure window for the buttons
    fig = figure('Position', [200, 200, 400, 400], 'MenuBar', 'none', 'ToolBar', 'none', 'NumberTitle', 'off', 'Name', 'Synthetic Sound Buttons');
    
    fs = 44100; % Sampling frequency for the audio signals
    duration = 1; % Duration of the sounds in seconds
    t = linspace(0, duration, fs * duration); % Time vector for generating the sounds

    % Define equations for the synthetic sounds
    equations = {@(t) sin(2 * pi * 440 * t), ... % Sine wave
                 @(t) square(2 * pi * 440 * t), ... % Square wave
                 @(t) sawtooth(2 * pi * 440 * t), ... % Sawtooth wave
                 @(t) chirp(t, 220, duration, 1000),... % Chirp (from 220 Hz to 1000 Hz)
                 @(t) cos(2 * pi * 380 * t), ... % Cosine wave
                 @(t) chirp(t, 220, duration, 1000) + sin(2 * pi * 440 * t)};% Combined chirp and sawtooth wave
             

    % Define layout for the buttons
    numRows = ceil(numel(equations) / 2); % Adjust rows based on the number of equations
    numCols = 2;
    buttonWidth = 160;
    buttonHeight = 80;
    padding = 20;
    totalButtonWidth = numCols * buttonWidth + (numCols - 1) * padding;
    totalButtonHeight = numRows * buttonHeight + (numRows - 1) * padding;
    startX = (400 - totalButtonWidth) / 2;
    startY = (400 - totalButtonHeight) / 2;

    % Create the buttons and add them to the figure
    for i = 1:numel(equations)
        row = ceil(i / numCols);
        col = mod(i - 1, numCols) + 1;
        x = startX + (col - 1) * (buttonWidth + padding);
        y = startY + (numRows - row) * (buttonHeight + padding);
        
        uicontrol('Style', 'pushbutton', 'Position', [x, y, buttonWidth, buttonHeight], 'String', ['Sound ', num2str(i)], 'Callback', {@playSound, equations{i}, fs, duration, t});
    end

    % Function to play the synthetic sound when a button is clicked
    function playSound(~, ~, equation, fs, duration, t)
        audio = equation(t); % Generate the audio signal using the specified equation
        sound(audio, fs); % Play the audio signal with the specified sampling frequency
        
        % Create a new figure for the plot
        figure('Position', [650, 200, 400, 300], 'NumberTitle', 'off', 'Name', 'Sound Waveform');
        plot(t, audio);
        title('Sound Waveform');
        xlabel('Time (s)');
        ylabel('Amplitude');
    end
end
