#include<iostream>
#include<conio.h>
#include<fstream>
using namespace std;
void Marks(string Name, string claas,float total,float per, float C,float P,float E,float Pa,float El,float I)
{
	ofstream marks("Stmarks.txt", ios::app);
	marks<<"Name : "<<Name<<"\n"<<"Class : "<<claas<<"\n";
	marks<<"Marks in Claculas = "<<C<<endl;
	marks<<"Marks in Programming = "<<P<<endl;
	marks<<"Marks in English = "<<E<<endl;
	marks<<"Marks in Pak studies = "<<Pa<<endl;
	marks<<"Marks in Basic Electornics = "<<El<<endl;
	marks<<"Marks in ICT = "<<I<<endl;
	marks<<"The Total marks is = "<<total<<endl;
	marks<<"The Percentage of Total marks is = "<<per<<endl;
	marks.close();
	
}
void Total( string Name,float C,float P,float E,float Pa,float El,float I)
{
	int total;
	total = C + P + E + Pa + El + I;
	cout<<"This Student named "<<Name<<" Has gotten a total of "<<total<<" marks"<<endl<<endl;
}
void Per(float C,float P,float E,float Pa,float El,float I)
{
	float Per = 0.0;
	Per = ((C + P + E + Pa + El + I)*100)/600;
   	cout <<"\n PERCENTAGE OF TOTAL MARKS = "<<Per<<endl<<endl;
}
void Status(string name, string clas, float C,float P,float E,float Pa,float El,float I)
{
	
    if(C >=33)
        {
    cout << name<<" , "<< clas<<endl;
                    	
   	cout << "STUDENT HAS PASSED CALCULAS"<<endl;
                    	
	}
	else 
	{
		cout << name<<" , "<< clas<<endl;
                    	
   	cout << "STUDENT HAS Failed CALCULAS"<<endl;
	}
	if(P >= 33)
	{
		cout << name<<" , "<< clas<<endl;
        cout << "STUDENT HAS PASSED Programming"<<endl;	
	}
	else
	{
			cout << name<<" , "<< clas<<endl;
        cout << "STUDENT HAS Failed Programming"<<endl;	
		
	}
	if(E >=33)
                    {
    cout << name<<" , "<< clas<<endl;
                    	
   	cout << "STUDENT HAS PASSED English"<<endl;
                    	
	}
	else
	{
	
	cout << name<<" , "<< clas<< endl;
                    	
   	cout << "STUDENT HAS Failed English"<<endl;
	}
	if(Pa >= 33)
	{
		cout << name<<" , "<< clas<< endl;
        cout << "STUDENT HAS PASSED Pak Studies"<<endl;	
	}
	else
	{
			cout << name<<" , "<< clas<<endl;
        cout << "STUDENT HAS Failed Pak Studies"<<endl;
	}
	if(El >=33)
                    {
    cout << name<<" , "<< clas<< endl;
                    	
   	cout << "STUDENT HAS PASSED Basic Electronics"<<endl;
                    	
	}
	else
	{
		cout << name<<" , "<< clas<< endl;
                    	
   	cout << "STUDENT HAS Failed Basic Electronics"<<endl;
	}
	if(I >= 33)
	{
		cout << name<<" , "<< clas<< endl;
        cout << "STUDENT HAS PASSED Ict"<<endl;	
	}
	else
	{
		cout << name<<" , "<< clas<<endl;
        cout << "STUDENT HAS Failed Ict"<<endl;
	}
	
}
int main()

{
	while(true)
	{
	cout<<" ******************STUDENT REPORT MANAGEMENT SYSTEM****************************";
	cout<<"                                                                                ";
	cout<<"                                                                                 ";
	
	
	char name [20];
	string clas;
	float Calculas, Programming, English, Pakstudy, Electronic, Ict;
	float total, per;
			cout<<" 1 .ENTER THE STUDENT NAME :";
			cin >> name;   
			cout<<endl;
			
		    cout<<" 2. ENTER THE STUDENTT CLASS :";
		    cin>> clas;
		    cout<<endl; 
			             
		    cout<<" 3.ENTER THE CALCULAS MARKS :";
		    cin>> Calculas;
		    cout<<endl;  
			           
		    cout<<" 4.ENTER THE PROGGRAMING MARKS:";
			cin>> Programming;
		    cout<<endl;      
			       
			cout<<" 5. ENTER THE ENGLISH MARKS :";
		    cin>> English;
		    cout<<endl;    
			          
		    cout<<" 6.ENTER THE pkstudy marks:";
		    cin>> Pakstudy;
			cout<<endl;
			
		    cout<<" 7.ENTER THE ELECTRONIC MARKS :";
		    cin>> Electronic;
		    cout<<endl;   
			         
		    cout<<" 8.ENTER THE ICT MARKS :";
		    cin>> Ict;
			cout<<"\n\n"; 
			total = (Calculas + Programming + English + Pakstudy + Electronic + Ict);
			per = ((Calculas + Programming + English + Pakstudy + Electronic + Ict)*100)/600;
		    Marks(name, clas,total, per,  Calculas, Programming, English, Pakstudy, Electronic,Ict);
		    Total( name, Calculas, Programming, English, Pakstudy, Electronic,Ict);
		    Status(name, clas, Calculas, Programming, English, Pakstudy, Electronic,Ict);
		    Per(Calculas, Programming, English, Pakstudy, Electronic,Ict);          
	cout<<endl<<endl;
	cout<<"Press enter to continue ";
		getche();
		system("cls");
		}
		return 0;
	}