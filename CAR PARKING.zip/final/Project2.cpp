#include<iostream>
#include<conio.h>
#include <fstream>
#include <ctime>
#include <string>

using namespace std;

void unparkVehicle() {
    string plateNumber;
    cout << "Enter the plate number of the vehicle: ";
    cin >> plateNumber;
    string line;
    ifstream recordFile("parking_record.txt");
    if (recordFile.is_open()) {
        ofstream tempFile("temp.txt");
        if (tempFile.is_open()) {
            while (getline(recordFile, line)) {
                if (line.find(plateNumber) == string::npos) {
                    tempFile << line << endl;
                }
            }
            tempFile.close();
            recordFile.close();
            remove("parking_record.txt");
            rename("temp.txt", "parking_record.txt");
            cout << "Record deleted successfully." << endl;
            getche();
        } else {
            cout << "Error: Unable to open file." << endl;
        }
    } else {
        cout << "Error: Unable to open file." << endl;
    }
    // Write the unparking information to a file
    ofstream unparkFile("unpark.txt", ios::app);
    if (unparkFile.is_open()) {
        time_t now = time(0);
        unparkFile << "Vehicle with plate number " << plateNumber << " was unparked at " << ctime(&now) << endl;
        unparkFile.close();
        cout << "Unparking information stored successfully." << endl;
    } else {
        cout << "Error: Unable to open file." << endl;
    }
}

void unparkAllVehicles() {
    // Code to unpark all vehicles
    std::ofstream recordFile("parking_record.txt", std::ios::trunc);
    if(recordFile.is_open())
    {
        std::cout<< "All records deleted successfully."<< std::endl;
        getche();
        recordFile.close();
    }
    else
    {
        std::cout<< "Error: Unable to open file."<< std::endl;
    }
}


void storeCredentials() {
    ofstream authFile("auth.txt");
    string username;
    string password;
    username ="admin";
    password ="12345678";
    if (authFile.is_open()) {
        authFile << username << std::endl;
        authFile << password << std::endl;
        authFile.close();
    } else {
        std::cout << "Error: Unable to open file." << std::endl;
    }
}

void titleDisplay(){
	system("cls");
	cout<<"|^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^|"<<endl;
	cout<<"|**********************************************************************************************************************|"<<endl;
	cout<<"|***********************************************|                       |**********************************************|"<<endl;
	cout<<"|***********************************************| WELCOME TO MY PROJECT |**********************************************|"<<endl;
	cout<<"|***********************************************|                       |**********************************************|"<<endl;
	cout<<"|**********************************************************************************************************************|"<<endl;
	cout<<"|^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^|"<<endl;
}
void total(int T) {
    int t_amo = T;
    int sum = 0;
    ifstream TotalFile("Total.txt", ios::in);
    if (TotalFile.is_open()) {
        TotalFile >> sum;
        TotalFile.close();
    } else {
        cout << "Error: Unable to open file." << endl;
    }
    sum = t_amo + sum;
    ofstream out("Total.txt", ios::out);
    if (out.is_open()) {
        out << sum << "\n";
        out.close();
    } else {
        cout << "Error: Unable to open file." << endl;
    }
}


void writeRecord(string plate, string type,  string money) {
    // Get the current date and time
    time_t now = time(0);
    char* dt = ctime(&now);
    string date(dt);
    date.erase(date.size() - 1);

    ofstream recordFile("parking_record.txt", ios::app);
    if (recordFile.is_open()) {
        recordFile << plate << "," << type << ", Rs "<< money <<","<< date << "\n";
        recordFile.close();
    } else {
        cout << "Error: Unable to open file." << endl;
    }
}

int main(){
//storeCredentials();
// Define variables to store the valid username and password read from the file
string validUsername;
string validPassword;

// Open the file and read the stored username and password
FILE *fp = fopen("auth.txt", "r");
if (!(fp == NULL)) {
	ifstream authFile("auth.txt");
	getline(authFile, validUsername);
    getline(authFile, validPassword);
    authFile.close();
}else {
    cout << "Error: Unable to open file." << endl;
    return 0;
}


while(true)
{
    system("cls");
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<"                                                                                                                        "<<endl;
    cout<<"                                                       AUTHORIZATION                                                    "<<endl;
    cout<<"                                                                                                                        "<<endl;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    for(int j=1;j<=60;j++)
    {
        cout<<"* ";
    }
    string username;
    string  password;
    cout<<endl;
    cout<<" _____________________________"<<endl;
    cout<<"|                             |"<<endl;
    cout<<"|     Enter the Username ::>  |";
    cin>>username;
    cout<<"|_____________________________|"<<endl;
    cout<<" _____________________________"<<endl;
    cout<<"|                             |"<<endl;
    cout<<"|     Enter the Password ::>  |";
    cin>>password;
    cout<<"|_____________________________|"<<endl;

    // Compare user input to the values read from the file
    if(username == validUsername && password == validPassword)
    {
        cout<<"**Access Granted**"<<endl;
        system("cls");
        break;
    }
    else
    {
        cout<<" ______________________________________________"<<endl;
        cout<<"|                                              |"<<endl;
        cout<<"|      Username Or Password Does Not Match     |"<<endl;
        cout<<"|______________________________________________|"<<endl;
        cout<<"|                                              |"<<endl;
        cout<<"|          Press any Key to continue ::>       |"<<endl;
        cout<<"|______________________________________________|"<<endl;
        getch();
    }
}
k:
int x;
int t_cnt=0;

    while (true) {
        system("cls");
        p:	
        titleDisplay();
        cout << " _____________________________" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 1. | Motorcycle             |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 2. | Rickshaw               |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 3. | Car                    |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 4. | Bus                    |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 5. | Check Record           |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 6. | Unpark Vehicle         |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 7. | Unpark All Vehicle     |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 8. | Total                  |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|    |                        |" << endl;
        cout << "| 9. | Exit                   |" << endl;
        cout << "|____|________________________|" << endl;
        cout << "|                             |" << endl;
        cout << "| Enter Your choice ::>  ";
        cin >> x;
        cout << "|_____________________________|" << endl;

        system("cls");
        titleDisplay();
        switch (x)
                {
            case 1:
                if (t_cnt < 100) {
                    string plate;
                    cout << "Enter the plate number ::> ";
                    cin >> plate;
                    t_cnt++;
                    writeRecord(plate, "Motorcycle", "20" );
                    total(20);
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|         MOTORCYCLE SUCCESSFULLY PARKED       |" << endl;
                    cout << "|______________________________________________|" << endl;
                    cout << "_________________________" << endl;
                    cout << "|                         |" << endl;
                    cout << "|  Motorcycle Amount :: " << "20" << "|" << endl;
                    cout << "|_________________________|" << endl;
                } else {
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|                PARKING IS FULL               |" << endl;
                    cout << "|______________________________________________|" << endl;
                }
                break;
            case 2:
                if (t_cnt < 100) {
                    string plate;
                    cout << "Enter the plate number ::> ";
                    cin >> plate;
                    t_cnt++;
                    writeRecord(plate, "Rickshaw", "30");
                    total(30);
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|          RICKSHAW SUCCESSFULLY PARKED        |" << endl;
                    cout << "|______________________________________________|" << endl;
                    cout << "_________________________" << endl;
                    cout << "|                         |" << endl;
                    cout << "|  Rickshaw Amount :: " << "30" << "|" << endl;
                    cout << "|_________________________|" << endl;
                } else {
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|                PARKING IS FULL               |" << endl;
                    cout << "|______________________________________________|" << endl;
                }
                break;
            case 3:
                if (t_cnt < 100) {
                    string plate;
                    cout << "Enter the plate number ::> ";
                    cin >> plate;
                    t_cnt ++;
                    writeRecord(plate, "Car", " 75");
                    total(75);
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|            CAR SUCCESSFULLY PARKED           |" << endl;
                    cout << "|______________________________________________|" << endl;
                    cout << "_________________________" << endl;
                    cout << "|                         |" << endl;
                    cout << "|  Car Amount :: " << "75" << "|" << endl;
                    cout << "|_________________________|" << endl;
                } else {
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|                PARKING IS FULL               |" << endl;
                    cout << "|______________________________________________|" << endl;
                }
                break;
            case 4:
                if (t_cnt < 100) {
                    string plate;
                    cout << "Enter the plate number ::> ";
                    cin >> plate;
                    t_cnt++;
                    writeRecord(plate, "Bus", "100");
                    total(100);
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|            BUS SUCCESSFULLY PARKED           |" << endl;
                    cout << "|______________________________________________|" << endl;
                    cout << "_________________________" << endl;
                    cout << "|                         |" << endl;
                    cout << "|  Bus Amount :: " << "100" << "|" << endl;
                    cout << "|_________________________|" << endl;
                } else {
                    cout << " ______________________________________________" << endl;
                    cout << "|                                              |" << endl;
                    cout << "|                PARKING IS FULL               |" << endl;
                    cout << "|______________________________________________|" << endl;
                }
                break;
            case 5:
                {
                    string plate;
                    cout << "Enter the plate number ::> ";
                    cin >> plate;
                    string line;
                    bool found = false;
                    ifstream recordFile("parking_record.txt");
                    if (recordFile.is_open()) {
                        while (getline(recordFile, line)) {
                            if (line.find(plate) != string::npos) {
                                cout << "Record found: " << line << endl;
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            cout << "Record not found for plate number " << plate << endl;
                        }
                        recordFile.close();
                    } else {
                        cout << "Error: Unable to open file." << endl;
                    }
                }
                break;
           case 6:
           	    {
           		    unparkVehicle();
			    }
			goto p;
		case 7:
			{
			unparkAllVehicles();
			system("cls");
			goto k;
			}
		case 8:
			{
		cout << " _____________________________ " << endl;	
		cout << "|                             |" << endl;
        cout << "|            Total            |" << endl;
        cout << "|_____________________________|" << endl<<endl;
        
        int sum = 0;
	    ifstream TotalFile("Total.txt", ios::in);
	    if (TotalFile.is_open()) {
	        TotalFile >> sum;
	        TotalFile.close();
	    } else {
	        cout << "Error: Unable to open file." << endl;
	    }
        
//        cout<<"The total number of vehical parked = "<<t_cnt<<endl<<endl;
        cout<<"The total money collected today = "<<sum;
        getch();
        goto p;
			}
		case 9:
			{
				system("cls");
			cout<<"\n\n\t\t\t\t\t\tThankyou for using my Program";
            return 0;
				
			}
			
        default:
        	{
        		cout << "Invalid choice. Please try again." << endl;
            break;
			}
            
        }
        cout << "Press any key to continue ::>";
        getch();
    }
    return 0;
}